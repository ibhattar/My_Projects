
public class FastTrackBatchStudent extends Student {
	 // Constructor
    public FastTrackBatchStudent(int studentId, String name, String mobileNo, String address, String course) {
        super(studentId, name, mobileNo, address, course);
    }

    // Override calculateFee method
    @Override
    public double calculateFee() {
        // Fast track fee calculation logic
        return 1500.0;
    }
}

