
public class corporateBatchStudent extends Student {
	  // Constructor
    public corporateBatchStudent(int studentId, String name, String mobileNo, String address, String course) {
        super(studentId, name, mobileNo, address, course);
    }

    // Override calculateFee method
    @Override
    public double calculateFee() {
        // Corporate batch fee calculation logic
        return 2000.0;
    }
}

