
public class CorporateWeekendBatchStudent extends Student {
    // Constructor
    public CorporateWeekendBatchStudent(int studentId, String name, String mobileNo, String address, String course) {
        super(studentId, name, mobileNo, address, course);
    }

    // Override calculateFee method
    @Override
    public double calculateFee() {
        // Corporate weekend batch fee calculation logic
        return 2500.0;
    }
}


