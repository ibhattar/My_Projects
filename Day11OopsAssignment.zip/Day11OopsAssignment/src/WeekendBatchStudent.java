
public class WeekendBatchStudent extends Student {
	   // Constructor
    public WeekendBatchStudent(int studentId, String name, String mobileNo, String address, String course) {
        super(studentId, name, mobileNo, address, course);
    }

    // Override calculateFee method
    @Override
    public double calculateFee() {
        // Weekend batch fee calculation logic
        return 1800.0;
    }
}

