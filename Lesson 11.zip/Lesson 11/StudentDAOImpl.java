package com.sms.dao.impl;

import java.util.Scanner;

import com.sms.dao.StudentDAO;
import com.sms.pojo.Student;

public class StudentDAOImpl implements StudentDAO {

	Student addStudent[]= new Student[3];
	Scanner sc = new Scanner(System.in);
	
	@Override
	public void addStudent() {
		// TODO Auto-generated method stub
for(int i = 0;i<3;i++)
{
System.out.println("Enter the Student Number: ");	
int sno = sc.nextInt();
System.out.println("Enter the student Name:");
String sname= sc.next();
System.out.println("Enter the Student Address:");
String sadd = sc.next();
System.out.println("Enter the mobile number:");
long mobileNumber = sc.nextLong();

Student student = new Student(sno,sname,sadd,mobileNumber);
addStudent[i]=student;

System.out.println("Student Registration Successfull");
}
	}

	@Override
	public Student[] viewAllStudents() {
		// TODO Auto-generated method stub
		return addStudent;
	}

	@Override
	public Student viewStudent(int sno) {
		// TODO Auto-generated method stub
		
		for(Student stu: addStudent)
		{
			if(stu!=null)
			{
				if(stu.getSno()==sno)
				{
					return stu;
				}
			}
		}
		return null;
	}

}
