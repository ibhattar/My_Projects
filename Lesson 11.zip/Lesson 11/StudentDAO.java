package com.sms.dao;

import com.sms.pojo.Student;

public interface StudentDAO {
void addStudent();
Student [] viewAllStudents();

Student viewStudent(int sno);







}
