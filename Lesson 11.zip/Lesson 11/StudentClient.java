package com.sms.client;

import java.util.Scanner;

import com.sms.dao.impl.StudentDAOImpl;
import com.sms.pojo.Student;

public class StudentClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		StudentDAOImpl daoImpl = new StudentDAOImpl();
		Scanner sc = new Scanner(System.in);

		while (true) {
			System.out.println("=================================");
			System.out.println("         1)AddStudent             ");
			System.out.println("         2)ViewALLStudent         ");
			System.out.println("         3)ViewStudent            ");
			System.out.println("         4)Exit                   ");
			System.out.println("=================================");

			System.out.println("Enter the choice");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				daoImpl.addStudent();
				break;
			case 2:
				Student[] viewAllStudents = daoImpl.viewAllStudents();
				System.out.println("--------------------------------------------");
				System.out.println("SNO \t SNAME \t SADD \t MOBILENUMBER");
				System.out.println("---------------------------------------------");

				for (Student stu : viewAllStudents) {
					System.out.println(
							stu.getSno() + "\t" + stu.getSname() + "\t" + stu.getSadd() + "\t" + stu.getMobileNumber());
				}
				break;
			case 3:
				System.out.println("Enter student Number");
				Student student = daoImpl.viewStudent(sc.nextInt());

				if (student != null)
					System.out.println(student.getSno() + "\t" + student.getSname() + "\t" + student.getSadd() + "\t"
							+ student.getMobileNumber());
				else
					System.out.println("Student record doesnot exist");

				break;
			case 4:
				System.out.println("Thank you for using the app.");
				System.exit(0);

			default:
				System.out.println("Choose between 1 to 4.");
			}
		} // end of the while loop

	}
}