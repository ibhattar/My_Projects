package com.shiva.service;

import java.util.List;

import com.shiva.entity.User;

public interface UserService {
	
	User createUser(User user);

	List<User> getAllUsres();
	
	User getUserById(Long userId);
	
	User updateUser(User user);
	
	boolean deleteUser(Long userId);
	
}
