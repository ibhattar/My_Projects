package com.shiva.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.shiva.entity.User;
import com.shiva.service.UserService;

@RestController
@RequestMapping("api/users")
public class UserController {
	@Autowired
	private UserService userService;

	
	//build create user Rest API
	//http://localhost:8081/api/users/create
	@PostMapping("/create")
	public ResponseEntity<User> createUser(@RequestBody    User user)
	{
		
		User savedUser = userService.createUser(user);
		return new ResponseEntity<>(savedUser,HttpStatus.CREATED);
	}
	
	//build get user by id Rest API
	
	//http://localhost:8081/api/users/fetch/1
	@GetMapping("/fetch/{id}")
	public ResponseEntity<User> getUserById(@PathVariable("id")     long userId)
	{
		User user = userService.getUserById(userId);
		
		return new ResponseEntity<>(user,HttpStatus.OK);
	}
	
	//http://localhost:8081/api/users/fetch
	//Build Get All Get All Users Rest API
	@GetMapping("/fetch")
	public ResponseEntity<List<User>> getAllUsers()
	{
		List<User> allUsres = userService.getAllUsres();
		
		
		
		return new ResponseEntity<>(allUsres,HttpStatus.OK);
	}
	
	
	//http://localhost:8081/api/users/update/3
	//Build Update User Rest API
	@PutMapping("/update/{id}")
	public ResponseEntity<User> updateUser(@PathVariable("id")   Long userId,@RequestBody    User user)
	{
		user.setId(userId);
		User updateUser = userService.updateUser(user);
		
		
		return new ResponseEntity<>(updateUser,HttpStatus.OK);

	}
	
	
	//Build Delete User Rest API
	//http://localhost:8081/api/users/delete/3
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<String> deleteUser(@PathVariable("id")    Long userId)
	{
		boolean deleteUser = userService.deleteUser(userId);
		String msg="";
		if(deleteUser)
			msg="User Successfully Deleted";
		else
			msg="User Not Exist";
		
		return new ResponseEntity<>(msg,HttpStatus.OK);

		}
	
	
	
	
	
	
	
	
	
	
	
	
	

}
