package com.indra.rest;

import org.hibernate.mapping.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.indra.entity.User;
import com.indra.service.UserService;
import com.indra.service.impl.UserServiceImpl;

@RestController
@RequestMapping("api/users")
public class UserController {

@Autowired

private UserService userService;

//build create user Rest API
@PostMapping("/create")
public ResponseEntity<User> createUser(@RequestBody User user)
{
	User savedUser = userService.createUser(user);
	
	return new ResponseEntity<>(savedUser,HttpStatus.CREATED);
}

// build get user by id Rest API

@GetMapping("/fetch/{id}")
public ResponseEntity<User> getUserById(@PathVariable("id") long userId){

User user = userService.getUserById(userId);

return new ResponseEntity<>(user,HttpStatus.OK);
}

// Build get all users to RestAPI
@GetMapping("/fetch")
public ResponseEntity<List> getAllUsers()
{
	List allUsers = UserService.getAllUsers();
	
	return new ResponseEntity<>(allUsers,HttpStatus.OK);
}

// Build Update User Rest API

@PutMapping("/update/{id}")
public ResponseEntity<User> updateUser (@PathVariable ("id") Long userId, @RequestBody User user)
{
	
	user.setId(userId);
	User updateUser = userService.updateUser(user);
	return new ResponseEntity<> (updateUser,HttpStatus.OK);
}

// Build Delete User RestAPI

@DeleteMapping("/delete/{id}")
public ResponseEntity<String> deleteUser(@PathVariable("id") Long userId)
{
	 boolean deleteUser = userService.deleteUser(userId);
	 
	 String msg ="";
	 if(deleteUser)
		 msg = "User deleted successfully";
	 else
		 msg ="user not exist";
	 
	return new ResponseEntity<>(msg,HttpStatus.OK);
}

}
