package com.indra.service;

import java.util.List;

import com.indra.entity.User;

public interface UserService {
	
	 User createUser(User user);

	 static org.hibernate.mapping.List getAllUsers() {
		// TODO Auto-generated method stub
		return null;
	}
	 
	 User getUserById(Long userId);
	 
	 User updateUser(User user);
	 
	 boolean deleteUser(Long userId);

	List<User> getAllUsers1();
}
