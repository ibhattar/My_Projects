package com.indra.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.indra.entity.User;
import com.indra.repo.UserRepository;
import com.indra.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepo;

	@Override
	public User createUser(User user) {
		// TODO Auto-generated method stub
		User saveUser = userRepo.save(user);
		return saveUser;
	}

	public List<User> getAllUsers() {
		// TODO Auto-generated method stub
		List<User> viewUsers = userRepo.findAll();
		return viewUsers;
	}

	@Override
	public User getUserById(Long userId) {
		// TODO Auto-generated method stub
		User user = userRepo.findById(userId).get();
		return user;
	}

	@Override
	public User updateUser(User user) {
		// TODO Auto-generated method stub
		//to find out id exist or not once exist update the data
		
		User existingUser = userRepo.findById(user.getId()).get();
		
		if(existingUser!=null)
		{
			existingUser.setFirstName(user.getFirstName());
		existingUser.setLastName(user.getLastName());
		existingUser.setEmail(user.getEmail());
		
		User updateUser = userRepo.save(existingUser);
		return updateUser;
		}
		else
		return null;
	}

	@Override
	public boolean deleteUser(Long userId) {
		// TODO Auto-generated method stub
		
		User existingUser = userRepo.findById(userId).get();
		if(existingUser!=null)
		{
			userRepo.deleteById(userId);
			return true;
		}
		
		else
		
		
		return false;
	}

	@Override
	public List<User> getAllUsers1() {
		// TODO Auto-generated method stub
		return null;
	}
}