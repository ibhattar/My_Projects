
public class Dominos {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double pizzacost=399.0;
		double discount= 0.20; //20% discoiunt 
		int pizzabought = 2;
		double pizzatotal= pizzacost*pizzabought;
		double finalbill= pizzatotal-pizzatotal*discount;
		
		System.out.println("Welcome to Dominoes");
		
		System.out.println("Pizza cost "+pizzacost);
		System.out.println("Total pizza cost :" +pizzatotal);
		System.out.println("Discount :: 20% ****");
		System.out.println("Final Bill Total :: "+finalbill);
		

	}

}
