
public class Jiofibernet {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		
		double monthlyrate= 699;
		double gst= 0.18;
		double gstAmt =  (monthlyrate)*gst ; 
		double monthlyplan = gstAmt+monthlyrate;
		// buy 6 months get 1 month free plan 
		
		double sixmonthpremium= 6*monthlyplan-monthlyplan;
		
		System.out.println("*** Welcome to Jio Fibernet ***");
		System.out.println("  Monthly Plan rate : "+monthlyrate);
		System.out.println("Monthly GST rate Amount (18% GST) : "+gstAmt);
		System.out.println("Montly plan Premium price  : "+monthlyplan);
		System.out.println("\n"+"\n");
		System.out.println(" Buy 6 months Plan get a Month Free Offer");
		System.out.println("New 6 month premium price :"+sixmonthpremium);
		

	}

}
