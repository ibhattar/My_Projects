// write a program to swap 4 numbers without temp variable 
public class swap4Numbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
		int a=2;
		int b=4;
		int c=6;
		int d=10;
		System.out.println("before swapping ::");
		System.out.println("a = "+a+"\t"+"b=  "+b+"\t"+"c = "+c+ "\t"+"d = "+d);

		//Swapping
		a = a + b + c +d;
		b = a - (b+c+d); // value of a assigned to b
		c = a - (b+c+d); // value of b assinged to c
		d = a - (b+c+d);// value of c assigned to d
		a = a- (b+c+d); // value of d assigned to a


		System.out.println("After swapping ::");
		System.out.println("a = "+a+"\t"+"b=  "+b+"\t"+"c = "+c+ "\t"+"d = "+d);

	}

}
