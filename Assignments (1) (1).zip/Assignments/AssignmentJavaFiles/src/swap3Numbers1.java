// swap three numbers without temp variables

public class swap3Numbers1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a=2;
		int b=4;
		int c=6;
		System.out.println("before swapping ::");
		System.out.println("a = "+a+"\t"+"b=  "+b+"\t"+"c = "+c);
		
		//Swapping
		
		a = a + b + c;
		b = a - (b+c); // value of a assigned to a
		c = a - (b+c); // value of b assinged to c
		a = a - (b+c);
		
		System.out.println("After swapping ::");
		System.out.println("a = "+a+"\t"+"b=  "+b+"\t"+"c = "+c);

	}

}
