/*
 * Mr sarath deposit 5 lakhs or 5 years with the interest rate if 6.8%
 * now calculate the interest amount he get after 5 years and final Acc
 * balance
 */
public class BankAcc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double indeposit= 500000;
		double interestrate= 0.068; //6.8% interest rate
		int time = 5;
		
		double interestAmt= indeposit*time*interestrate;
		double finalbalance= indeposit+interestAmt;
		
		System.out.println("Initial Depost : Rs "+indeposit);
		System.out.println("Interest Rate 6.8%");
		System.out.println("Interets Accured after 5 years : Rs "+interestAmt);
		System.out.println("Final Acc Balance after % years : Rs"+finalbalance);
		
	}

}
