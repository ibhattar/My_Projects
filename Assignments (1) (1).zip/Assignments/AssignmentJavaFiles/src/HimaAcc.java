
/* Hima Basic Salary is 85000, her company provude ta,da,hra
 * now calculate himas gross salary  and net salary 
 * net amount 
 * net amount include pf,tax
 * ta 15% da 20%,hra 18%, pf 20%, tax is 25%
 */
public class HimaAcc {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	double salary = 85000;
	double TA=0.15; //15%
	double DA =0.20;//20%
	double HRA = 0.18; //18%
	double pf=0.20;
	double tax= 0.25;
	
	double TaAmt=salary*TA;
	double DaAmt=salary*DA;
	double HraAmt= salary*HRA;
	double pfAmt=salary*pf;
	double TaxAmt= salary*tax;
	
	double Grossincome = salary+TaAmt+DaAmt+HraAmt;
	
	double netIncome = Grossincome-(pfAmt+TaAmt);
		
	System.out.println(" Hima Basic Salary : Rs"+salary);	
	System.out.println("Ta 15%  Rs"+TaAmt);	
	System.out.println("Da 20%  Rs"+DaAmt);	
	System.out.println("Hra 18%  Rs"+HraAmt);	
	System.out.println("Hima's Gross Income for the Month: Rs"+Grossincome);	
	System.out.println("Hima's Net Income After tax and pf: Rs"+netIncome);	

		
		
	}

}
