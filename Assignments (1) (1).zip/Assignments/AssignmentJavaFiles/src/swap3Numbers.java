// write a program to swap three number with the help of third variable temp
public class swap3Numbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a=2;
		int b=4;
		int c=6;
		System.out.println("before swapping ::");
		System.out.println("a = "+a+"\t"+"b=  "+b+"\t"+"c = "+c);
		
		//Swapping
		int temp;
		temp=a ;
		a=b;
		b=c;
		c= temp;
		
		
		System.out.println("After swapping ::");
		System.out.println("a = "+a+"\t"+"b=  "+b+"\t"+"c = "+c);
		
	}

}
