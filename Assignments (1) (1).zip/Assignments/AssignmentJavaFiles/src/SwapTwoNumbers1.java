//write a program to swap tw numbers without temp variable 
public class SwapTwoNumbers1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int fNum=100;
		int sNum=300;
		
		System.out.println("Before swapping ");
		System.out.println("fNum  : "+fNum + "\t"+ "sNum  : "+sNum);
		
		//Swapping 
		
		fNum=sNum +fNum;;
		sNum= fNum -sNum;
		fNum=fNum-sNum;
		System.out.println("After  swapping ");
		System.out.println("fNum  :"+fNum + "\t"+ "sNum  : "+sNum);
		

	}

}
