//mr vikrant salary is 85000 , he pays 20% income tax to the government
// calculate the tax amount and net income  after tax
public class salary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double salary =85000;
		double tax= 0.20;
		
		System.out.println("Mr Vikrants Monthly Salary is : Rs "+salary);
		System.out.println("Monthly Tax Amount : Rs"+salary*tax);
		System.out.println("Monthly Net income After Taxation : Rs"+tax(1,salary,tax));
		System.out.println("\n");
		System.out.println("Annual Salary of Vikrant : Rs "+salary*12);
		System.out.println("Annual Income tax For Vikrant : Rs "+salary*12*tax);
		System.out.println("Annual Net income After Taxation : Rs"+tax(12,salary,tax));

	}
	
	public static double tax(int i, double a, double b) {
		double x;
		x=i*a-(i*a*b);
		
		 return x;
	}

}
