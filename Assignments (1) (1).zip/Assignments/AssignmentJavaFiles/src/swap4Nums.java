// write a program to swap 4 numbers with temp variable 
public class swap4Nums {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=2;
		int b=4;
		int c=6;
		int d=10;
		System.out.println("before swapping ::");
		System.out.println("a = "+a+"\t"+"b=  "+b+"\t"+"c = "+c+ "\t"+"d = "+d);
		
		//Swapping
		int temp;
		temp=a ;
		a=b;
		b=c;
		c= d;
		d=temp;;
		
		
		System.out.println("After swapping ::");
		System.out.println("a = "+a+"\t"+"b=  "+b+"\t"+"c = "+c+ "\t"+"d = "+d);
		
	}

}
