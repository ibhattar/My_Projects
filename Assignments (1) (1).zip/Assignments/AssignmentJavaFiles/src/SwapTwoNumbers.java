//write a program to swap two numbers wiyh temp variable
public class SwapTwoNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int fNum=100;
		int sNum=300;
		int temp;
		System.out.println("Before swapping ");
		System.out.println("fNum  : "+fNum + "\t"+ "sNum  : "+sNum);
		
		//Swapping 
		temp=fNum;
		fNum=sNum;
		sNum=temp;
		System.out.println("After  swapping ");
		System.out.println("fNum  :"+fNum + "\t"+ "sNum  : "+sNum);
		
	}

}
