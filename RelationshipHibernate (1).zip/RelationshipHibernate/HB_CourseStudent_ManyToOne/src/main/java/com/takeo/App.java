package com.takeo;

import java.util.ArrayList;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.takeo.entity.Course;
import com.takeo.entity.Student;
import com.takeo.utility.SessionUtility;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {

    Session ses = SessionUtility.getSession();
    Transaction tx=ses.beginTransaction();
    
    
    Course co=new Course();
    co.setCname("Maths");
    
    co.setCfee(200);
    
    
    Course co1=new Course();
 co1.setCname("English");
    
    co1.setCfee(100);
    
    
    
    List<Course>courses=new ArrayList<>();
    courses.add(co);
    courses.add(co1);
    
 Student s=new Student();
    
    s.setSname("Dolma");
    
    co.setStudent(s);
    co1.setStudent(s);

    
    ses.persist(co);
    ses.persist(co1);

    tx.commit();
    

    
    
     
    }
}
