
	package com.takeo.entity;

	import javax.persistence.CascadeType;
import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

	@Entity
	@Table(name = "COURSE")
	public class Course {

		@Id
		@Column(name = "CID")
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private int cid;
		@Column(name = "CNAME")
		private String cname;
		@Column(name = "DURATION")
		private int cduration;
		@Column(name = "FEE")
		private int cfee;
		
		@ManyToOne(cascade = CascadeType.ALL)
		@JoinColumn(name =   "SID")
		private Student student;
		
		
		public Student getStudent() {
			return student;
		}
		public void setStudent(Student student) {
			this.student = student;
		}
		public int getCid() {
			return cid;
		}
		public void setCid(int cid) {
			this.cid = cid;
		}
		public String getCname() {
			return cname;
		}
		public void setCname(String cname) {
			this.cname = cname;
		}
		public int getCduration() {
			return cduration;
		}
		public void setCduration(int cduration) {
			this.cduration = cduration;
		}
		public int getCfee() {
			return cfee;
		}
		public void setCfee(int cfee) {
			this.cfee = cfee;
		}
		
		

}
