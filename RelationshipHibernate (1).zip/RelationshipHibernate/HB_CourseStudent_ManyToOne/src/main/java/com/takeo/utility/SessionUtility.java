package com.takeo.utility;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class SessionUtility {

	public static Session getSession()
	{
//Step 1:  Create/Instatiate Configuration
    	
    	Configuration cfg=new Configuration();
    System.out.println(cfg.getProperty("hibernate.connection.driver_class"));
    cfg.configure("hibernate.cfg.xml");
    System.out.println(cfg.getProperty("hibernate.connection.driver_class"));
    
   // Step 2 : Build Session Factory
    
    SessionFactory factory=cfg.buildSessionFactory();
    
   // Create Session Object
    
    Session ses=factory.openSession();
    
return ses;		
		
	}
	
	
}
