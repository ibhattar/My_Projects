package com.takeo.entity;

	import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
	import javax.persistence.Entity;
	import javax.persistence.GeneratedValue;
	import javax.persistence.GenerationType;
	import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

	@Entity
	@Table(name = "STUDENT")
	public class Student {

		@Id
		@Column(name = "SID")
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private int sid;
		@Column(name = "SNAME")
		private String sname;
		@Column(name = "SADD")
		private String sadd;
		@Column(name = "MOBILE_NUMBER")
		private long mobileNumber;
		@Column(name = "EMAIL")
		private String email;
		
		@OneToMany(cascade = CascadeType.ALL)
		@JoinColumn(name = "CID")
		private List<Course> courses;
		
		
		public List<Course> getCourses() {
			return courses;
		}
		public void setCourses(List<Course> courses) {
			this.courses = courses;
		}
		public int getSid() {
			return sid;
		}
		public void setSid(int sid) {
			this.sid = sid;
		}
		public String getSname() {
			return sname;
		}
		public void setSname(String sname) {
			this.sname = sname;
		}
		public String getSadd() {
			return sadd;
		}
		public void setSadd(String sadd) {
			this.sadd = sadd;
		}
		public long getMobileNumber() {
			return mobileNumber;
		}
		public void setMobileNumber(long mobileNumber) {
			this.mobileNumber = mobileNumber;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		
	}