package com.takeo;

import java.util.ArrayList;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;

import com.takeo.entity.Department;
import com.takeo.entity.Employee;
import com.takeo.utility.SessionUtility;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {

    Session ses = SessionUtility.getSession();
    Transaction tx=ses.beginTransaction();
    
    
    Employee em=new Employee();
    em.setEname("Dolma");  
    em.setSalary(20000);
    
    
    Employee em1=new Employee();
    em1.setEname("Gojo");
    em1.setSalary(100000);
    
    
    
    List<Employee>employees=new ArrayList<>();
    employees.add(em);
    employees.add(em1);
    
    Department s=new Department();
    
    s.setDname("Java");
    
    s.setEmployees(employees);

    
    ses.persist(s);

    tx.commit();
    

    
    
     
    }
}
