
//Author: Indra Bhattarai
//Date: Dec-03-2023

public class OddNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num = 11;
		if(num%2!=0)
			System.out.println("The given number is Odd.");
			else
				System.out.println("The given number is Even.");	
	}

}
