
public class DisplayEvenNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		System.out.println("Even Numbers between 1 and 100 is:");
int i= 2;
for(i=1;i<=100; i++)
	if (i%2==0)
		
	{
		System.out.print(i+" ");
	}

	}

}
