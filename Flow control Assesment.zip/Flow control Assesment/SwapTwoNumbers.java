// Name: Indra Bhattarai
//Date: Dec-02-2023



public class SwapTwoNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int temp;
int x = 100;
int y = 200;

// now swapping of two numbers
temp = x;
x = y;
y = temp;

System.out.println("x ="+x +" y ="+y);

	}

}
