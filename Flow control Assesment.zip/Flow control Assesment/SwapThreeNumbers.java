// Name: Indra Bhattarai
//Date: Dec-02-2023


public class SwapThreeNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	int temp;
	int x = 100;
	int y = 200;
	int z = 300;
	
     temp = x;
	x=y;
	y=z;
	z= temp;

	
	System.out.println("x ="+ y + " y ="+x +" z "+z);
	}

}
