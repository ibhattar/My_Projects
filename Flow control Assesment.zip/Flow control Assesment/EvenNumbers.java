
// Author: Indra Bhattarai
//Date: Dec-03-2023


public class EvenNumbers {


	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num = 82;
		if (num%2==0)
			System.out.println("The given number is Even.");
			else
		System.out.println("The given number is Odd.");

	}

}
