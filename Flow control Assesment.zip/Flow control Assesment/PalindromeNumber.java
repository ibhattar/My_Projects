
// Author: Indra Bhattarai
//Date: Dec-03-2023

import java.util.Scanner;

public class PalindromeNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num;
		System.out.println("Enter the number:");
		Scanner sc = new Scanner(System.in);
		num = sc.nextInt();

		int reversedNum = 0, temp = num;
		while (temp > 0) {
			int remainder = temp % 10;
			reversedNum = reversedNum * 10 + remainder;
			temp = temp / 10;

		}
		if (num == reversedNum)
			System.out.println("Given Number is Palindrome.");
		else
			System.out.println("Given Number is not a Palindrome.");
	}
}
