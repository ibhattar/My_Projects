
// Author: Indra Bhattarai
// Date: Dec-03-2023


import java.util.Scanner;
public class ArmstrongNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int num;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the number:");
		num = sc.nextInt();

		System.out.println("Given number is an armstrong Number." + armstrong(num));
	}

	static boolean armstrong(int n) {
		int digits = 0, temp;
		int sum = 0;
		temp = n;
		while (temp > 0) {
			temp = temp / 10;
			digits++;
		}
		System.out.println("Number of digits:"+digits);
		temp = n;
		while (temp > 0) {
			int lastDigit = temp % 10;
			sum = (int) (sum + Math.pow(lastDigit, lastDigit));
			temp = temp / 10;
		}
		System.out.println("Sum is:"+sum);
		if (sum == n)
			return true;
		
		return false;

	}
}
