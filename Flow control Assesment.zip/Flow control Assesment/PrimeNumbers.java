
//Author: Indra Bhattarai
//Date: Dec-03-2023

public class PrimeNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int num = 5;
boolean isPrime = true;
for(int i =2;i<= num/2; i++) {
if(num % i==0) {
	isPrime= false;
	break;
}}
	if (isPrime)
	{
		System.out.println("The given number is Prime Number.");
	}
	else {
		System.out.println("The given Number is not a Prime Number.");
}
	

	}

}
