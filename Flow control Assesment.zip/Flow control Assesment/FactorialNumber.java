
// Author: Indra Bhattarai
//Date: Dec-03-2023


public class FactorialNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int num = 6;
long fac = 1; //Note I used long data type because sometime the factorial will become very large

for (int i = 1; i<=num; i++)
{
	fac = fac*i;
}
System.out.println("Factorial of a number is:"+fac);
	}

}
