import org.hibernate.Session;
import org.hibernate.Transaction;

import com.takeo.entity.Customer;
import com.takeo.utility.SessionUtility;

public class InsertClient {

    public static void main(String[] args) {
        try (Session session = SessionUtility.getSession()) { // Obtain a Hibernate session
            Transaction transaction = session.beginTransaction(); // Begin a transaction

            // Create a new Customer entity
            Customer customer = new Customer();
            customer.setId(3);
            customer.setCname("Yuki");
            customer.setCno(12345);
            customer.setCadd("Astoria");
            customer.setCity("Queens");
            customer.setCountry("USA");

            session.persist(customer); // Persist the entity

            transaction.commit(); // Commit the transaction
        } catch (Exception e) {
            System.out.println("An error occurred while inserting the customer: " + e.getMessage());
        }
    }
}
