
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.NativeQuery;

import com.takeo.entity.Customer;
import com.takeo.utility.SessionUtility;

public class ViewClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Session ses = SessionUtility.getSession();
		Transaction tx = ses.beginTransaction();

		NativeQuery q = ses.createSQLQuery("select * from customer");
		q.addEntity("e", Customer.class);
		List<Customer> cusRecords = q.getResultList();
		cusRecords.stream().forEach(e -> System.out.println(e.getCno() + "\t" + e.getCname() + "\t" + e.getId() + "\t"
				+ e.getCadd() + "\t" + e.getCity() + "\t" + e.getCountry() + "\t" + e.getPcode()));
	}
}