package com.takeo.client;

import java.util.List;
import java.util.Scanner;

import com.takeo.dao.CustomerDAO;
import com.takeo.dao.impl.CustomerDAOImpl;
import com.takeo.entity.Customer;


public class CustomerClient {
	public static void main(String[] args) {

	CustomerDAOImpl cDao =new CustomerDAOImpl();
		Scanner sc = new Scanner(System.in);		
		
		while (true) {
			System.out.println(" -----------------------------------------------");
			System.out.println("|             1)Add Customer                    |");
			System.out.println("|             2)View All Customers              |");
			System.out.println("|             3)View Customer                   | ");
			System.out.println("|             4)Update Customer                 |");
			System.out.println("|             5)Delete Customer                 |");
			System.out.println("|             6)Exit                            |");
			System.out.println(" -----------------------------------------------");

			System.out.println("Enter one option");
			int choice = sc.nextInt();

			switch (choice) {
			case 1:
				Customer newCustomer = new Customer(); // Create a new Customer object
                System.out.println("Enter customer id:");
                newCustomer.setId(sc.nextInt());
                System.out.println("Enter customer name:");
                newCustomer.setCname(sc.next());
                cDao.addCustomer(newCustomer);
                System.out.println("Customer added");
                break;
			case 2:
				List<Customer> viewAllCustomers = cDao.viewAllCustomers();
				System.out.println("ID" + "\t" + "customer");

				for (Customer p : viewAllCustomers) {
					System.out.println(p.getId() + "\t" + p.getCname());
				}

				break;
			case 3:

				System.out.println("Enter Customer Id");

				Customer p = cDao.viewCustomer(sc.nextInt());
				System.out.println("ID" + "\t" + "Customer");

				if (p != null) {
					System.out.println(p.getId() + "\t" + p.getCname());

				} else
					System.out.println("Deosnt Exist Look At After Some Time");
				break;
			case 4:

				cDao.updateCustomer(choice);

				break;
			case 5:
				cDao.deleteCustomer(choice);

		
				break;
			case 6:
				System.out.println("Thanks for Using!");
				System.exit(0);
			default:
				System.out.println("Choose option 1 to 6");
			}
		}
	}
}