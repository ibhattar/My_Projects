package com.takeo.dao;

import java.util.List;

import com.takeo.entity.Customer;

public interface CustomerDAO {
	String addCustomer(Customer cust);
	List<Customer> viewAllCustomers();
	Customer viewCustomer(int id);
	String updateCustomer(int id);
	boolean deleteCustomer(int id);
	

}
