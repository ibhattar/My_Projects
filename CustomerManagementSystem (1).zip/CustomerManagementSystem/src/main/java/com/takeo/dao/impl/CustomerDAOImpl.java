package com.takeo.dao.impl;

import java.util.ArrayList;

import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import com.takeo.dao.CustomerDAO;
import com.takeo.entity.Customer;

public class CustomerDAOImpl implements CustomerDAO {
	Scanner sc = new Scanner(System.in);
	List<Customer> custom = new ArrayList<>();


    @Override
    public String addCustomer(Customer cust) {
    	custom.add(cust);
        return null;
		
    }

    @Override
    public List<Customer> viewAllCustomers() {
        return custom; 
    }

    @Override
    public Customer viewCustomer(int id) {
    	for (Customer ca : custom) {
			if (ca.getId() == id) {
				return ca;
			}
    }
    	return null;
    }

    @Override
    public String updateCustomer(int id) {
    	System.out.println("Enter the Customer id to update: ");
		int customerToUpdate = sc.nextInt();

		for (Customer c : custom) {
			if (c.getId() == customerToUpdate) {
				System.out.println("Enter the new Customer Name: ");
				String newCustomerName = sc.next();

				c.setCname(newCustomerName);
				 System.out.println("Customer updated sucessfully");
				 return"Customer updated sucessfully";

			}

		}
		 System.out.println("Customer not found");
		return null;
    }

    @Override
    public boolean deleteCustomer(int id) {
    	System.out.println("Enter the Customer ID to Remove: ");
		int customerToDelete = sc.nextInt();
		sc.nextLine();

        Iterator<Customer> iterator = custom.iterator();

        while (iterator.hasNext()) {
        	Customer c = iterator.next();

            if (c.getId() == customerToDelete) {
                iterator.remove(); // Use iterator to safely remove the category
                System.out.println("Customer "+c.getCname()+ " deleted successfully");
                return true;
            }
        }

        System.out.println("Customer not found");
        return false; // Return false if the category was not found and deleted
}

	
}
