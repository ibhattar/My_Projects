package com.takeo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "CUSTOMER")
public class Customer {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="CID")
	private int id;
	@Column(name="CNAME")
	private String cname;
	@Column(name="CNUM")
	private int cno;
	@Column(name="ADDRESS")
	private String cadd;
	@Column(name="CITY")
	private String city;
	@Column(name="POSTAL")
	private int pcode;
	@Column(name="COUNTRY")
	private String country;
	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public int getCno() {
		return cno;
	}
	public void setCno(int cno) {
		this.cno = cno;
	}
	public String getCadd() {
		return cadd;
	}
	public void setCadd(String cadd) {
		this.cadd = cadd;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getPcode() {
		return pcode;
	}
	public void setPcode(int pcode) {
		this.pcode = pcode;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public Customer(int id, String cname,int cno, String cadd, String city,int pcode,String country ) {
		super();
		this.id = id;
		this.cname = cname;
		this.cno = cno;
		this.cadd = cadd;
		this.city = city;
		this.pcode = pcode;
		this.country=country;
		
		
	}
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}