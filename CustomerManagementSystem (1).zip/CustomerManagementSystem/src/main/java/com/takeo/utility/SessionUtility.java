package com.takeo.utility;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class SessionUtility {
	public static Session getSession() {

		// Create/instantiate configuration
		Configuration cfg = new Configuration();
		System.out.println(cfg.getProperty("hibernate.connection.driver_class"));
		cfg.configure("hibernate.cfg.xml");
		System.out.println(cfg.getProperty("hibernate.connection.driver_class"));
		// Build session factory
		SessionFactory factory = cfg.buildSessionFactory();
		// Create session object
		Session ses = factory.openSession();
		return ses;
	}

}
