package com.takeo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.takeo.entity.Customer;

public class App 
{
    public static void main( String[] args )
    {
    	Configuration cfg = new Configuration();
		System.out.println(cfg.getProperty("hibernate.connection.driver_class"));
		cfg.configure("hibernate.cfg.xml");
		System.out.println(cfg.getProperty("hibernate.connection.driver_class"));
//Build session factory
		SessionFactory factory = cfg.buildSessionFactory();
		// Create session object
		Session ses = factory.openSession();
		Transaction tx = ses.beginTransaction();
		Customer cus = new Customer();
		cus.setCname("Dolma");
		cus.setId(1);
		cus.setCno(123456789);
		cus.setCadd("Elm");
		cus.setCity("Elmhurst");
		cus.setPcode(12345);
		cus.setCountry("Usa");


		ses.persist(cus);
		tx.commit();
		

    }
}
