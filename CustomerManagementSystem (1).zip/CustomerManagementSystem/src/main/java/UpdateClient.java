import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.takeo.entity.Customer;

public class UpdateClient {

    public static void main(String[] args) {
        Configuration cfg = new Configuration();
        cfg.configure("hibernate.cfg.xml"); // Load Hibernate configuration from XML

        try (SessionFactory factory = cfg.buildSessionFactory(); // Create SessionFactory
             Session session = factory.openSession()) { // Open a new session
            Transaction tx = session.beginTransaction(); // Begin transaction

            // Create or update a Customer entity
            Customer customer = new Customer();
            customer.setId(102);
            customer.setCname("Pema");
            customer.setCno(2);
            customer.setCadd("Woodside");
            customer.setCity("Queens");
            customer.setCountry("USA");

            session.saveOrUpdate(customer); // Save or update the entity

            tx.commit(); // Commit the transaction
        } catch (Exception e) {
            System.out.println("An error occurred while updating the customer: " + e.getMessage());
        }
    }
}
