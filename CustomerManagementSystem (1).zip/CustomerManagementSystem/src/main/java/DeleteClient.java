import org.hibernate.Session;
import org.hibernate.Transaction;

import com.takeo.entity.Customer;
import com.takeo.utility.SessionUtility;

public class DeleteClient {

    public static void main(String[] args) {
        try (Session session = SessionUtility.getSession()) {
            Transaction transaction = session.beginTransaction();

            // Load the Customer entity by its ID
            Customer customer = session.load(Customer.class, 3); // Assuming the ID to delete is 3

            if (customer != null) {
                session.delete(customer); // Delete the Customer entity
                transaction.commit(); // Commit the transaction
                System.out.println("Customer deleted successfully");
            } else {
                System.out.println("Customer with ID 3 not found");
            }
        } catch (Exception e) {
            System.out.println("An error occurred while deleting the customer: " + e.getMessage());
        }
    }
}
