
public class Pat34 {
	public static void main(String[] args) {
		    for (int i = 0; i < 4; i++) {
		        // Print spaces
		        for (int k = 0; k < i; k++) {
		            System.out.print("");
		        }

		        // Print increasing letters
		        char alpha = 'A';
		        for (int j = 0; j <= i; j++) {
		            System.out.print(alpha);
		            alpha++;
		        }

		        // Print decreasing letters
		        for (int j = i - 1; j >= 0; j--) {
		            alpha--;
		            System.out.print(alpha);
		        }

		        System.out.println();
		    }
		}
	}

	

