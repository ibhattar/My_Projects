
public class Pat30 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


	        // Print upper part of the pattern
		for (int i = 1; i <= 5; i++) {
			char alpha = 'A';

			for (int j = 1; j <= 5 - i +1; j++) {
				System.out.print(alpha);
				alpha++;
			}
			System.out.println();
		}

		// Print lower part of the pattern
		for (int i = 2; i <= 5; i++) {
			char alpha = 'A';

			for (int j = 1; j <= i; j++) {
				System.out.print(alpha);
				alpha++;
			}
			System.out.println();
		}
	}

	}
	
	   

	


