
public class Pat13 {
	public static void main(String[] args) {

		for (int i = 0; i < 5; i++) {
			// Print spaces for alignment
			for (int space = 0; space < 5 - i; space++) {
				System.out.print("  ");
			}

			// Print alphabets for the pyramid
			for (int j = 0; j <= i; j++) {
				char alphabet = (char) ('A' + i);
				System.out.print(alphabet + "   ");
			}

			// Move to the next line after completing each row
			System.out.println();
		}
	}

}
