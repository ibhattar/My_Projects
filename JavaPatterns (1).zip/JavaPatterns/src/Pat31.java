
public class Pat31 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i = 5; i >= 1; i--) {
			char alpha = 'E';

			for (int j = 1; j <= i; j++) {
				System.out.print(alpha);
				alpha--;
			}
			System.out.println();
		}

		// Print lower part of the pattern
		for (int i = 2; i <= 5; i++) {
			char alpha = 'E';

			for (int j = 1; j <= i; j++) {
				System.out.print(alpha);
				alpha--;
			}
			System.out.println();
		}
	}

}
