public class Pat8 {
	 public static void main(String[] args) {

		 for (int i = 1; i <= 5; i++) {
	            // Print spaces for alignment
	            for (int space = 1; space <= 5 - i; space++) {
	                System.out.print("  ");
	            }

	            // Print numbers for the pyramid
	            int startNumber = 5;
	            for (int j = 1; j <= i; j++) {
	                System.out.print(startNumber-- + "   ");
	            }

	            // Move to the next line after completing each row
	            System.out.println();
	        }
	    }
 }
	        
	          

    
	

        
