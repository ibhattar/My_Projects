
public class Pat19 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for (int i = 5; i >= 1; i--) {
			char alphabet = 'E';

			for (int j = 1; j <= i; j++) {
				System.out.print(alphabet);
				alphabet--;
			}

			System.out.println();
		}
	}

}
