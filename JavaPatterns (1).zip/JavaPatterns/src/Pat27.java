
public class Pat27 {
	public static void main(String[] args) {

		// Print upper part of the pattern
		for (int i = 1; i <= 5; i++) {
			// Print spaces
			for (int k = 1; k <= 5 - i; k++) {
				System.out.print(" ");
			}

			// Print stars
			for (int j = 1; j <= i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}

		// Print lower part of the pattern
		for (int i = 5 - 1; i >= 1; i--) {
			// Print spaces
			for (int k = 1; k <= 5 - i; k++) {
				System.out.print(" ");
			}

			// Print stars
			for (int j = 1; j <= i; j++) {
				System.out.print("*");
			}
			System.out.println();
		}
	}
}
