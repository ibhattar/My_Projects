
public class Pat24 {
	public static void main(String[] args) {

        // Print upper part of the pattern
        for (int i = 1; i <=5 ; i++) {
            for (int j = 1; j <= i; j++) {
                System.out.print(j);
            }
            System.out.println();
        }

        // Print lower part of the pattern
        for (int i = 5 - 1; i >= 1; i--) {
            for (int j = 1; j <= i; j++) {
                System.out.print(j);
            }
            System.out.println();
        }
}
}
