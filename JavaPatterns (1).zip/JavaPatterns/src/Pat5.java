
public class Pat5 {
	public static void main(String[] args) {

		for (int i = 1; i <= 5; i++) {
			char currentChar = (char) ('A' + i - 1);
			for (int j = 1; j <= i; j++) {
				System.out.print(currentChar);
			}

			System.out.println();
		}
	}

}
