
public class Pat22 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			for (int i = 0; i < 5; i++) {
				int number = 1;

				// Print spaces for alignment
				for (int k = 1; k <= 5 - i; k++) {
					System.out.print("  ");
				}

				for (int j = 0; j <= i; j++) {
					System.out.print(number + "   ");
					number = number * (i - j) / (j + 1);
				}
				System.out.println();
			}
		}
	

	}


