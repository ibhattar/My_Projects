public class Pat7 {
	public static void main(String[] args) {
		for (int i = 1; i <= 5; i++) {
            // Print spaces for alignment
            for (int space = 1; space <= 5 - i; space++) {
                System.out.print("  ");
            }

            // Print numbers for the pyramid
            for (int j = 1; j <= i; j++) {
                System.out.print(j + "   ");
            }

            System.out.println();
		}
	}
}
