
public class Pat33 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for (int i = 1; i <= 4; i++) {
			// Print spaces
			for (int k = 4 - i; k >= 1; k--) {
				System.out.print(" ");
			}

			// Print increasing numbers
			for (int j = 1; j <= i; j++) {
				System.out.print(j);
			}

			// Print decreasing numbers
			for (int j = i - 1; j >= 1; j--) {
				System.out.print(j);
			}

			System.out.println();
		}
	}

}
