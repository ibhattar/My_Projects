
public class Pat37 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (char i = 'a'; i <= 'e'; i++) {
			for (char j = 'a'; j <= 'e'; j++) {
				if (j <= i) {
					System.out.print(i);
				} else {
					System.out.print(j);
				}
			}
			System.out.println();
		}
	}

}
