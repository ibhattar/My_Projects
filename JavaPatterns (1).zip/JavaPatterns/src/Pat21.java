
public class Pat21 {
	public static void main(String[] args) {
		char alphabet = 'A';
		for (int i = 1; i <= 5; i++) {
			// Print alphabets for each row

			for (int j = 1; j <= i; j++) {
				System.out.print(alphabet);
				alphabet++;
			}

			// Move to the next line after completing each row
			System.out.println();
		}
	}

}
