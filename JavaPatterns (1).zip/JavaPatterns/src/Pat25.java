
public class Pat25 {
	public static void main(String[] args) {

        // Print upper part of the pattern
        for (int i = 1; i <= 5; i++) {
            char currentChar = 'A';
            for (int j = 1; j <= i; j++) {
                System.out.print(currentChar);
                currentChar++;
            }
            System.out.println();
        }

        // Print lower part of the pattern
        for (int i = 5 - 1; i >= 1; i--) {
            char currentChar = 'A';
            for (int j = 1; j <= i; j++) {
                System.out.print(currentChar);
                currentChar++;
            }
            System.out.println();
        }
    }

}
