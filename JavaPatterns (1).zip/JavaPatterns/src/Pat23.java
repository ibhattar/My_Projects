
public class Pat23 {
	public static void main(String[] args) {
		for (int i = 0; i < 5; i++) {
			int number = 1;
			char alpha='A';
			char a = 0;
			

			// Print spaces for alignment
			for (int k = 1; k <= 5 - i; k++) {
				System.out.print("  ");

			}

			for (int j = 0; j <= i; j++) {
				
				System.out.print(alpha+ "   ");
				alpha++;

				//a =    (char) (a * (i - j) / (j + 1));

			}
			System.out.println();
		}
	}
}
