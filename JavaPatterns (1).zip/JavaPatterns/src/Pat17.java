public class Pat17 {
	public static void main(String[] args) {
		int number = 1;

		for (int i = 1; i <= 5; i++) {
			// Print numbers for each row
			for (int j = 1; j <= i; j++) {
				System.out.print(number + " ");
				number++;
			}

			// Move to the next line after completing each row
			System.out.println();
		}
	}

}
