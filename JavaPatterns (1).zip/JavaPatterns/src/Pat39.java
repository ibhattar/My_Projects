
public class Pat39 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		for (int i = 1; i <= 5; i++) {
			// Print spaces for alignment
			for (int space = 1; space <= 5 - i; space++) {
				System.out.print("  ");
			}

			// Print alphabets for the pyramid
			char currentChar = 'A';
			for (int j = 1; j <= i; j++) {
				System.out.print(currentChar + "   ");
				currentChar++;
			}

			System.out.println();
		}

		for (int i = 4; i >= 1; i--) {
			// Print spaces for alignment
			for (int space = 0; space <= 4 - i; space++) {
				System.out.print("  ");
			}

			// Print alphabets for the pyramid
			char currentChar = 'A';
			for (int j = 1; j <= i; j++) {
				System.out.print(currentChar + "   ");
				currentChar++;
			}

			System.out.println();
		}

	}

}
