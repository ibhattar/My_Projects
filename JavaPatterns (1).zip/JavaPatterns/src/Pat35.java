
public class Pat35 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for (int i = 0; i < 5; i++) {
			for (int j = 0; j < 5; j++) {
				if (j == i) {
					int number = i + 1;
					int divisor = 1000;

					for (int k = 0; k < 4; k++) {
						int digit = number / divisor;
						System.out.print(digit);
						number %= divisor;
						divisor /= 10;
					}
				} else {
					System.out.print("0");
				}
			}
			System.out.println();
		}
	}
}
