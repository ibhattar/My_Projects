
public class Pat29 {
	public static void main(String[] args) {

        // Print upper part of the pattern
		for (int i = 5; i >= 1; i--) {
            for (int j = i; j >= 1; j--) {
                System.out.print(j);
            }
            System.out.println();
        }

        // Print lower part of the pattern
        for (int i = 2; i <= 5; i++) {
            for (int j = i; j >= 1; j--) {
                System.out.print(j);
            }
            System.out.println();
        
        }
    }
}

