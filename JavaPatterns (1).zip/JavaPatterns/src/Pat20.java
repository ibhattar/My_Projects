
public class Pat20 {
	public static void main(String[] args) {

        for (int i = 1; i <= 5; i++) {
            char currentChar = 'E';
            for (int j = 1; j <= i; j++) {
                System.out.print(currentChar);
                currentChar--;
            }

            System.out.println();
        }
    }

}
