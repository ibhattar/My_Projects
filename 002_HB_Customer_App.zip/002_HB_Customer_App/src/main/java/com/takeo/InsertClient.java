package com.takeo;

import javax.persistence.Query;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.takeo.entity.Customer;

public class InsertClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// step 1: create a configuration file

				Configuration cfg = new Configuration();
				System.out.println(cfg.getProperty("hibernate.connection.driver_class"));
				cfg.configure("hibernate.cfg.xml");
				System.out.println(cfg.getProperty("hibernate.connection.driver_class"));

				// step 2: Build a session Factory

				SessionFactory factory = cfg.buildSessionFactory();

				// step 3 create a object

				Session ses = factory.openSession();

				Transaction tx = ses.beginTransaction();
		
	Customer c = ses.get(Customer.class,100	);
	if(c!=null);
	String abc = "Delete from"+"where id =:cid";
	Query query = ses.createQuery(abc);
	query.setParameter("cid", 100);
	int result = query.executeUpdate();
	
	System.out.println("Rows affected:"+result);
	
	
	tx.commit();
	
	
		
	}

}
