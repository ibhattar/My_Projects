package com.takeo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.takeo.entity.Customer;

public class UpdateClient {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		// step 1: create a configuration file

				Configuration cfg = new Configuration();
				System.out.println(cfg.getProperty("hibernate.connection.driver_class"));
				cfg.configure("hibernate.cfg.xml");
				System.out.println(cfg.getProperty("hibernate.connection.driver_class"));

				// step 2: Build a session Factory

				SessionFactory factory = cfg.buildSessionFactory();

				// step 3 create a object

				Session ses = factory.openSession();

				Transaction tx = ses.beginTransaction();
				
				Customer cus = new Customer();
				cus.setCid(101);
				cus.setCname("Shiva");
				cus.setEmail("shiva@gmail.com");
				cus.setPhone("2485631212");
				
				Customer c = (Customer)ses.merge(cus);
				
				if (c!=null)
					System.out.println(c.getCid()+"\t"+c.getCname()+"\t"+c.getEmail()+"\t"+c.getPhone());
	
ses.saveOrUpdate(c);
	
	}
	
	

}
