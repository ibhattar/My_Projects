package com.takeo;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.takeo.entity.Customer;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
// step 1: create a configuration file

		Configuration cfg = new Configuration();
		System.out.println(cfg.getProperty("hibernate.connection.driver_class"));
		cfg.configure("hibernate.cfg.xml");
		System.out.println(cfg.getProperty("hibernate.connection.driver_class"));

		// step 2: Build a session Factory

		SessionFactory factory = cfg.buildSessionFactory();

		// step 3 create a object

		Session ses = factory.openSession();

		Transaction tx = ses.beginTransaction();

		Customer cus = new Customer(); // Transient State

		cus.setCid(100);
		cus.setCname("Indra");
		cus.setEmail("Indra@gmail.com");
		cus.setPhone("2489066314");

		Integer id = (Integer) ses.save(cus); // persistance state

		tx.commit();
	}
}
