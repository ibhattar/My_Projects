
//Author: Indra Bhattarai
//Date: Dec-03-2023

public class FloydTriangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub


int num = 1;
for(int row = 1; row<=5; row++)	
{
	for(int column = 1; column<=row;column++)	{
		System.out.print(num+" ");
		num++;
	}
	System.out.println();
}
	}

}
