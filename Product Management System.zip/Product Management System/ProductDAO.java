package com.pms.daoo;

import com.pms.pojo.Product;

public interface ProductDAO {
	void addProduct();
	Product [] viewAllProductss();

	Product viewProduct(int pid);

}
