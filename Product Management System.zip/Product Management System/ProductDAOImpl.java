package com.pms.dao.Impl;
import java.util.Scanner;
import com.pms.daoo.ProductDAO;
import com.pms.pojo.Product;

public class ProductDAOImpl implements ProductDAO {

	Product addProduct[]= new Product[3];
	Scanner sc = new Scanner(System.in);
	
	public void addProduct() {
		// TODO Auto-generated method stub
for (int i = 0;i<3;i++)
{
	System.out.println("Enter the Product Identification Number:");
	int pid= sc.nextInt();
	System.out.println("Enter the name of the product: ");
	String pname = sc.next();
	System.out.println("Enter the quantity of the product:");
	int qty = sc.nextInt();
	System.out.println("Enter the Price of the product:");
	int price = sc.nextInt();
	
	Product product = new Product(pid,pname,qty,price);
	addProduct[i]= product;
	
	System.out.println("Product is available in the store.");
}
	}

	@Override
	public Product[] viewAllProductss() {
		// TODO Auto-generated method stub
		return addProduct;
	}

	public Product viewProduct(int pid) {
		// TODO Auto-generated method stub
		
		for(Product pro:addProduct)
		{
			if (pro!=null)
			{
				if(pro.getPid()==pid)
				{
					return pro;
				}
			}
		}
		
		return null;
	}

}
