package com.pms.client;
import java.util.Scanner;
	

import com.pms.dao.Impl.ProductDAOImpl;
import com.pms.pojo.Product;

public class ProductClient {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ProductDAOImpl daoImpl = new ProductDAOImpl();
		Scanner sc = new Scanner(System.in);

		while (true) {
			System.out.println("=================================");
			System.out.println("         1)AddProduct             ");
			System.out.println("         2)ViewAllProduct         ");
			System.out.println("         3)ViewProduct            ");
			System.out.println("         4)Exit                   ");
			System.out.println("=================================");

			System.out.println("Enter the choice");
			int choice = sc.nextInt();
			switch (choice) {
			case 1:
				daoImpl.addProduct();
				break;
			case 2:
				Product[] viewAllProducts = daoImpl.viewAllProductss();
				System.out.println("--------------------------------------------");
				System.out.println("PID \t PNAME \t QTY \t PRICE");
				System.out.println("---------------------------------------------");

				for (Product pro : viewAllProducts) {
					System.out.println(
							pro.getPid() + "\t" + pro.getPname() + "\t" + pro.getQty() + "\t" + pro.getPrice());
				}
				break;
			case 3:
				System.out.println("Enter Prouct ID");
				Product product = daoImpl.viewProduct(sc.nextInt());

				if (product != null)
					System.out.println(product.getPid() + "\t" + product.getPname() + "\t" + product.getQty() + "\t"
							+ product.getPrice());
				else
					System.out.println("Student record doesnot exist");

				break;
			case 4:
				System.out.println("Thank you for using the app.");
				System.exit(0);

			default:
				System.out.println("Choose between 1 to 4.");
			}
		} // end of the while loop

	}

	}


