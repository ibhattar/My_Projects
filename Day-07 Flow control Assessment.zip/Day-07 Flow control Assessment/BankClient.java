
//Author : Indra Bhattarai
//Date: 11/30/2023



import java.util.Scanner;

public class BankClient {
	int initialbalance, addedbalance, result;

	int deposit(int initialbalance, int addedbalance) {
		result = initialbalance + addedbalance;
		return result;
	}

	int withdraw(int initialbalance, int addedbalance) {
		result = initialbalance - addedbalance;
		return result;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner sc = new Scanner(System.in);

BankClient demo = new BankClient();

		while(true)
		{
System.out.println("=======================================");
System.out.println("             1)Deposit                  ");
System.out.println("             2)Withdraw                  ");
System.out.println("             3)BalanceEnq                 ");
System.out.println("             4)Exit                       ");
System.out.println("=======================================");


System.out.println("Enter the choice.");
int choice = sc.nextInt();
int initialbalance,addedbalance,result;
// Switch case
switch(choice)
{
case 1:
	System.out.println("Enter the initial Amount:");
	initialbalance = sc.nextInt();
	System.out.println("Enter the added Amount:");
	addedbalance = sc.nextInt();
	result= demo.deposit(initialbalance,addedbalance);
	System.out.println("The new balance is:"+result);
	break;
	
case 2:
	System.out.println("Enter the initial Amount:");
	initialbalance = sc.nextInt();
	System.out.println("Enter the added Amount:");
	addedbalance = sc.nextInt();
	result= demo.withdraw(initialbalance,addedbalance);
	System.out.println("The new balance is:"+result);
	break;

case 3:
	System.out.println("Thank you for using the application");
	System.exit(0);
	default:
		System.out.println("Choose the number between 1 to 4");
}


	} // End of the while Loop

}
}
