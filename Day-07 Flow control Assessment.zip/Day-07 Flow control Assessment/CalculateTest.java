
//Author: Indra Bhattarai
//Date: 11/30/2023



import java.util.Scanner;

public class CalculateTest {
	int fno, sno, result;

	int add(int fno, int sno) {
		result = fno + sno;
		return result;
	}

	int sub(int fno, int sno) {
		result = fno - sno;
		return result;
	}

	int mul(int fno, int sno) {
		result = fno * sno;
		return result;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner sc = new Scanner(System.in);

		CalculateTest demo = new CalculateTest();

		while (true) {
			System.out.println("=========================================");
			System.out.println("              1)ADD                       ");
			System.out.println("              1)SUB                       ");

			System.out.println("              1)MUL                       ");
			System.out.println("              1)EXIT                       ");

			System.out.println("=========================================");

			System.out.println("Enter the choice");
			int choice = sc.nextInt();
			int fno, sno, result;

			// Switch Case

			switch (choice) {
			case 1:
				System.out.println("Enter the First Number:");
				fno = sc.nextInt();
				System.out.println("Enter the second Number:");
				sno = sc.nextInt();
				result = demo.add(fno, sno);
				System.out.println("Addition of two numbers:" + result);
				break;

			case 2:
				System.out.println("Enter the First Number:");
				fno = sc.nextInt();
				System.out.println("Enter the second Number:");
				sno = sc.nextInt();
				result = demo.sub(fno, sno);
				System.out.println("Substraction of two numbers:" + result);
				break;

			case 3:
				System.out.println("Enter the First Number:");
				fno = sc.nextInt();
				System.out.println("Enter the second Number:");
				sno = sc.nextInt();
				result = demo.mul(fno, sno);
				System.out.println("Multiplication of two numbers:" + result);
				break;

			case 4:
				System.out.println("Thank you for using the application.");
				System.exit(0);
			default:
				System.out.println("Choose between 1 to 4");

			}

		} // end of the while loop

	}

}
