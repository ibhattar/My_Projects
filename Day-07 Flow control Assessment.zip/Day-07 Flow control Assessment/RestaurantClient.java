
//Author: Indra Bhattarai
//Date: 11/30/2023

import java.util.Scanner;
public class RestaurantClient {
	
	int idly_Price = 50;
	int idly_Bill = 0;
	int Dosa_Price = 70;
	int Dosa_Bill = 0;
	int Puri_Price = 45;
	int Puri_Bill = 0;
	int total_bill = 0;
	
	Scanner sc = new Scanner(System.in);
	void idly() {
	System.out.println("How many Plates if idly would you like?");
	int plates = sc.nextInt();
	idly_Bill = plates*idly_Price;
	System.out.println("The cost of idly is"+idly_Bill);
	}
	
	void Dosa () {
		System.out.println("How many Plates if Dosa would you like?");
		int plates = sc.nextInt();
		Dosa_Bill = plates*idly_Price;
		System.out.println("The cost of Dosa is"+Dosa_Bill);
	}
	void Puri () {
		System.out.println("How many Plates if Puri would you like?");
		int plates = sc.nextInt();
		Puri_Bill = plates*idly_Price;
		System.out.println("The cost of Puri is"+Puri_Bill);
	}
	
	void total_bill()
	{
		total_bill = idly_Bill+Puri_Bill+Dosa_Bill;
		System.out.println("The total bill is "+total_bill);
	}
	
	
public static void main(String[] args) {
		// TODO Auto-generated method stub
	
	
Scanner sc = new Scanner(System.in);
RestaurantClient demo = new RestaurantClient();
		while(true)
		{
System.out.println("================================================");	
System.out.println("                       1)Idly                   ");
System.out.println("                       2)Dosa                  ");
System.out.println("                       3)Puri                   ");
System.out.println("                       4)Bill                   ");
System.out.println("                       5)Exit                   ");
System.out.println("================================================");

System.out.println("Enter the choice of your breakfast.");
int choice = sc.nextInt();
switch(choice)
{
case 1:
	demo.idly();
break;
case 2:
	demo.Dosa();
	break;
case 3:
	demo.Puri();
	break;
case 4:
	demo.total_bill();
	break;
case 5:
	System.out.println("Thank you for using the APP");
	System.exit(0);
	default:
		System.out.println("Please choose between 1 to 4");
	
		} // closing the while loop
	}

}
}