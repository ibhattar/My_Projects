import java.util.Arrays;
import java.util.List;

public class CountNum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
List<String> stringList = Arrays.asList("apple","banana","orange","animal","anatoly");

char targetLetter = 'a';

//specify the target letter

long count = countStringsWithStartingLetter(stringList,targetLetter);
System.out.println("Number of strings starting with "+targetLetter +":"+count);
	}
	public static long countStringsWithStartingLetter(List<String> strings, char targetLetter) {
		return strings.stream().filter(s -> s.toLowerCase().startsWith(String.valueOf(targetLetter).toLowerCase()))
				.count();
		
	}

}
