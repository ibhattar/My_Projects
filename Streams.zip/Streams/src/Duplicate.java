import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Duplicate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
List<Integer> dup = Arrays.asList(10,23,1,2,5,2,9,8,5,7,6,10,23);

List<Integer> num = removeDuplicates(dup);

System.out.println("List without duplicates:"+num);
	}
	public static List<Integer> removeDuplicates(List<Integer>numbers){
		return numbers.stream()
				.distinct()
				.collect(Collectors.toList());
	}

}
