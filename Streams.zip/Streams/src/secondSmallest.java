import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class secondSmallest {

	private static final int Integer = 0;
	private static final int List = 0;

	public static void main(String[] args) {
		// TODO Auto-generated method stub
List<Integer> num = Arrays.asList(2,3,5,4,6,8,9,10);

Optional<Integer> ss = findSecondSmallest(num);

if(secondSmallest.isPresent()) {
	System.out.println("Second Smallest Element:" + secondSmallest.get());
	{
		System.out.println("Thanks for trying.");
	}
}

public static Optional<Integer>findSecondSmallest(List<Integer> num){
	return num.stream()
			.distinct() // prompt to remove duplicate
			.sorted()
			.skip(1)   
			.findFirst();
}
	}

	private static String get() {
		// TODO Auto-generated method stub
		return null;
	}

	private static Optional<Integer> findSecondSmallest(List<Integer> num) {
		// TODO Auto-generated method stub
		return null;
	}

	private static boolean isPresent() {
		// TODO Auto-generated method stub
		return false;
	}

}
