import java.util.Arrays;
import java.util.List;
import java.util.Optional;

public class MinMax {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
List<Integer> num = Arrays.asList(1,2,3,4,5,8,7,9,0,12,15);

// minimum value
Optional<Integer> minValue = findMinValue(num);
System.out.println("Minimum Value:"+minValue.orElse(null));

// maximum value

Optional<Integer> maxValue = findMaxValue(num);
System.out.println("Maximum Value"+maxValue.orElse(null));
	}
	public static Optional<Integer> findMinValue(List<Integer> num){
		return num.stream()
				.min(Integer::compareTo);
	}
	public static Optional<Integer> findMaxValue(List<Integer> num){
		return num.stream()
				.max(Integer::compareTo);
	}

}
