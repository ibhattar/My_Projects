import java.util.Arrays;
import java.util.List;

public class Average {

    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(10, 2, 3, 4, 5, 6, 7, 8, 9, 10);

        double average = calculateAverage(numbers);

        System.out.println("Average: " + average);
    }

    public static double calculateAverage(List<Integer> numbers) {
        return numbers.stream()
                .mapToDouble(Integer::doubleValue)
                .average()
                .orElse(0.0);
    }
}
