import java.util.Arrays;
import java.util.List;

public class SortStrings {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
List<String> stringList = Arrays.asList("indra","apple","ram","banana");

//sorting in the ascending order
List<String> ascendingOrder = sortAscending(stringList);
System.out.println("Ascending Order:"+ascendingOrder);

// sorting in descending order

List<String> descendingOrder = sortDescending(stringList);
System.out.println("Descending Order:"+descendingOrder);
	}
	private static List<String> sortDescending(List<String> stringList) {
		// TODO Auto-generated method stub
		return null;
	}
	public static List<String> sortAscending(List<String> strings){
	 return strings.stream()
	 .sorted(s1, s2) -> s2.compareTo(s1))
     .collection(Collectors.toList());
	}

}
