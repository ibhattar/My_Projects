import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StringConverter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		List<String>stringList = Arrays.asList("Indra","ram","shiva","java");
		
		//convert to uppercase
		List<String>uppercaseList = convertToUppercase(stringList);
		System.out.println("Uppercase List:"+uppercaseList);
		
		// Convert to lowercase
		List<String> lowercaseList = convertToLowercase(stringList);
		System.out.println("Lowercase List:"+lowercaseList);
		
	}
	public static List<String> convertToUppercase (List<String> strings){
		return strings.stream()
				.map(String::toUpperCase)
				.collect(Collectors.toList());
	}
	public static List<String> convertToLowercase(List<String>strings){
		return strings.stream()
				.map(String::toLowerCase)
				.collect(Collectors.toList());
 	}

}
