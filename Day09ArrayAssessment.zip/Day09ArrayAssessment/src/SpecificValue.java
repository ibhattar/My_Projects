
public class SpecificValue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int[] numbers = {10,20,30,40,50,60,70,10};
 int targetValue = 10;
 
 boolean containsValue =  containsValue(numbers,targetValue);
 
 if(containsValue) {
	 System.out.println("Array has the value "+ targetValue);
 }
 else
 {
	 System.out.println("Array doesnot have the value"+targetValue);
 }
	}
	public static boolean containsValue(int[]array,int targetValue) {
		for(int num: array) {
			if(num == targetValue) {
				return true;
			}
		}
		return false;
	}

}
