

// Java program to find the index value of the element of the array
public class IndexValue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] numbers = { 4,5,6,3,8,7,9,100,14,50,63};
		 int targetValue = 7;
		 
		 int index = findIndex(numbers,targetValue);
		 
		 if(index != -1) {
			 System.out.println("Index of"+targetValue + index);
		 }
		 else {
			 System.out.println(targetValue + "elements not found");
		 }
		 }
		
	public static int findIndex(int[]array,int targetValue) {
		for(int i =0; i<array.length;i++) {
			if(array[i]==targetValue) {
				return i;
			}
		}
		return -1; //
			}
		
	}


