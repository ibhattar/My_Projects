public class MaxMinArray {
    public static void main(String[] args) {
        // Sample array
        int[] numbers = {10, 5, 8, 20, 3, 15};

        // Finding maximum and minimum values
        int max = findMaxValue(numbers);
        int min = findMinValue(numbers);

        // Displaying the results
        System.out.println("Maximum value in the array: " + max);
        System.out.println("Minimum value in the array: " + min);
    }

    // Function to find the maximum value in an array
    private static int findMaxValue(int[] array) {
        int max = array[0];

        for (int i = 1; i < array.length; i++) {
            if (array[i] > max) {
                max = array[i];
            }
        }

        return max;
    }

    // Function to find the minimum value in an array
    private static int findMinValue(int[] array) {
        int min = array[0];

        for (int i = 1; i < array.length; i++) {
            if (array[i] < min) {
                min = array[i];
            }
        }

        return min;
    }
}
