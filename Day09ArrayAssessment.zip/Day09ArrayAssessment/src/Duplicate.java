
// Write a java program to find duplicate values

import java.util.HashMap;
import java.util.Map;

public class Duplicate {
    public static void main(String[] args) {
        // Sample array with duplicates
        int[] numbers = {1, 2, 3, 4, 2, 5, 6, 1, 7, 8, 4, 9};

        // Finding and printing duplicate values
        findAndPrintDuplicates(numbers);
    }

    // Function to find and print duplicate values in an array
    private static void findAndPrintDuplicates(int[] array) {
        Map<Integer, Integer> countMap = new HashMap<>();

        // Count the occurrences of each element in the array
        for (int num : array) {
            countMap.put(num, countMap.getOrDefault(num, 0) + 1);
        }

        // Print duplicate values
        System.out.println("Duplicate values in the array:");

        for (Map.Entry<Integer, Integer> entry : countMap.entrySet()) {
            if (entry.getValue() > 1) {
                System.out.println(entry.getKey());
            }
        }
    }
}
