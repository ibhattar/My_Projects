// Java program to find the index value of the element

public class SpecificElement {

    public static void main(String[] args) {
        int[] numbers = {5, 10, 15, 20, 25, 30, 35, 40, 45, 50};
        int targetValue = 30;

        int index = findIndex(numbers, targetValue);

        if (index != -1) {
            System.out.println("Index of " + targetValue + ": " + index);
        } else {
            System.out.println(targetValue + " not found in the array.");
        }
    }

    public static int findIndex(int[] array, int targetValue) {
        for (int i = 0; i < array.length; i++) {
            if (array[i] == targetValue) {
                return i;
            }
        }
        return -1; // Return -1 if the target value is not found in the array
    }
}
