
// write a java program to reverse an array

public class ReverseArray {
    public static void main(String[] args) {
        // Sample array
        int[] numbers = {1, 2, 3, 4, 5};

        // Display original array
        System.out.println("Original Array:");
        displayArray(numbers);

        // Reverse the array
        reverseArray(numbers);

        // Display reversed array
        System.out.println("\nReversed Array:");
        displayArray(numbers);
    }

    // Function to reverse an array of integers
    private static void reverseArray(int[] array) {
        int start = 0;
        int end = array.length - 1;

        while (start < end) {
            // Swap elements at start and end indices
            int temp = array[start];
            array[start] = array[end];
            array[end] = temp;

            // Move indices towards the center
            start++;
            end--;
        }
    }

    // Function to display the elements of an array
    private static void displayArray(int[] array) {
        for (int num : array) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}
