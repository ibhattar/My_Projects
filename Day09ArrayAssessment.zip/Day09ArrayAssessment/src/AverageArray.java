
// Author: Indra Bhattarai


public class AverageArray {

    public static void main(String[] args) {
        int[] numbers = {5, 10, 15, 20, 25, 30, 35, 40, 45, 50};

        double average = calculateAverage(numbers);

        System.out.println("Average: " + average);
    }

    public static double calculateAverage(int[] array) {
        if (array.length == 0) {
            return 0.0; // Handle the case where the array is empty to avoid division by zero
        }

        int sum = 0;
        for (int num : array) {
            sum += num;
        }

        return (double) sum / array.length;
    }
}
