
// Java Program to remove specific element of the array
	import java.util.Arrays;

	public class RemoveElement {

	    public static void main(String[] args) {
	        int[] numbers = {5, 10, 15, 20, 25, 30, 35, 40, 45, 50};
	        int targetValue = 30;

	        System.out.println("Original Array: " + Arrays.toString(numbers));

	        numbers = removeElement(numbers, targetValue);

	        if (numbers != null) {
	            System.out.println("Array after removing " + targetValue + ": " + Arrays.toString(numbers));
	        } else {
	            System.out.println(targetValue + " not found in the array.");
	        }
	    }

	    public static int[] removeElement(int[] array, int targetValue) {
	        int index = -1;

	        for (int i = 0; i < array.length; i++) {
	            if (array[i] == targetValue) {
	                index = i;
	                break;
	            }
	        }

	        if (index != -1) {
	            int[] newArray = new int[array.length - 1];
	            System.arraycopy(array, 0, newArray, 0, index);
	            System.arraycopy(array, index + 1, newArray, index, array.length - index - 1);
	            return newArray;
	        } else {
	            return null; // Return null if the target value is not found in the array
	        }
	    }
	}
