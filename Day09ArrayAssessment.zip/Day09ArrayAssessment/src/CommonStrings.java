
// Java Program to find the common value in arrays.
import java.util.HashSet;
import java.util.Set;

public class CommonStrings {
    public static void main(String[] args) {
        // Sample string arrays
        String[] array1 = {"indra", "orange", "apple", "kiwi"};
        String[] array2 = {"indra", "kiwi", "grape", "apple"};

        // Finding and printing common string values
        findAndPrintCommonStrings(array1, array2);
    }

    // Function to find and print common string values between two arrays
    private static void findAndPrintCommonStrings(String[] array1, String[] array2) {
        Set<String> set1 = new HashSet<>();
        Set<String> commonStrings = new HashSet<>();

        // Add elements from the first array to set1
        for (String str : array1) {
            set1.add(str);
        }

        // Check common elements with the second array
        for (String str : array2) {
            if (set1.contains(str)) {
                commonStrings.add(str);
            }
        }

        // Print common string values
        System.out.println("Common string values between the two arrays:");

        for (String commonString : commonStrings) {
            System.out.println(commonString);
        }
    }
}
