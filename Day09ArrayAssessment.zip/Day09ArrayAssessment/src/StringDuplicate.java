

// write a java program to find duplicate of a string
import java.util.HashMap;
import java.util.Map;

public class StringDuplicate {
    public static void main(String[] args) {
        // Sample string array with duplicates
        String[] strings = {"indra", "bronx", "indra", "apple", "bronx", "usa", "usa"};

        // Finding and printing duplicate values
        findAndPrintStringDuplicates(strings);
    }

    // Function to find and print duplicate values in a string array
    private static void findAndPrintStringDuplicates(String[] array) {
        Map<String, Integer> countMap = new HashMap<>();

        // Count the occurrences of each string in the array
        for (String str : array) {
            countMap.put(str, countMap.getOrDefault(str, 0) + 1);
        }

        // Print duplicate values
        System.out.println("Duplicate values in the string array:");

        for (Map.Entry<String, Integer> entry : countMap.entrySet()) {
            if (entry.getValue() > 1) {
                System.out.println(entry.getKey());
            }
        }
    }
}
