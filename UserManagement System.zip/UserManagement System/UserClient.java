package com.ums.client;

import java.util.Scanner;

import com.ums.dao.Impl.UserDAOImpl;

public class UserClient {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		UserDAOImpl daoImpl = new UserDAOImpl();
while(true)
{
		// TODO Auto-generated method stub
		System.out.println("--------------------------------------");
		System.out.println("                  1)Register            ");
		System.out.println("                  2) LogIn              ");
		System.out.println("                  3)ForgotPassword       ");
		System.out.println("                  4)Exit                  ");
		System.out.println("--------------------------------------");

		System.out.println("Enter the choice");
		int choice = sc.nextInt();

		switch (choice) {
		case 1:
			daoImpl.addUsers();
			break;

		case 2:
			System.out.println("Enter Username:");
			String uname = sc.next();
			System.out.println("Enter the Password:");
			String pass = sc.next();
			
			boolean flag = daoImpl.verifyUnameAndPass(uname,pass);
			if (flag)
			{
				System.out.println("Valid User");
			}
			else
				System.out.println("Invalid User");
			break;
			
		case 4:
			System.out.println("Thank you for using the application:");
			System.exit(0);
			
			default:
				System.out.println("Choose between 1 to 4:");
			}
		}

	}

}
