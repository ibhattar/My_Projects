package com.ums.dao;

public interface UserDAO {
public void addUsers();
boolean verifyUnameAndPass(String uname,String pass );
String forGotPassword(String uname);
}
