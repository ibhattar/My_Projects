package com.ums.dao.Impl;

import java.util.Scanner;
import java.util.ArrayList;

import com.ums.dao.UserDAO;
import com.ums.pojo.User;

public class UserDAOImpl implements UserDAO {

	ArrayList<User> addUsers = new ArrayList<>();
	Scanner sc = new Scanner(System.in);

	@Override
	public void addUsers() {
		// TODO Auto-generated method stub
		int k = 1;
		while (k == 1) {

			System.out.println("Enter the ID");
			int uid = sc.nextInt();
			System.out.println("Enter the first name");
			String fname = sc.next();
			System.out.println("Enter the Last Name");
			String lname = sc.next();
			System.out.println("Enter the username");
			String uname = sc.next();
			System.out.println("Enter the password");
			String pass = sc.next();

			
			User user = new User(uid, fname, lname, uname, pass);

			addUsers.add(user);
			System.out.println("Registration Successfull.");
			System.out.println("Do you want to add more record");
			k = sc.nextInt();
		} // end of while
	}

	@Override
	public boolean verifyUnameAndPass(String uname, String pass) {
		// TODO Auto-generated method stub
		boolean flag = false;

		for (User user : addUsers) {
			if (user.getUserName().equals(uname) && user.getPassword().equals(pass)) {
				flag = true;
				break;
			}
		}
		return flag;
	}

	@Override
	public String forGotPassword(String uname) {
		// TODO Auto-generated method stub
		for (User user : addUsers) {
			if (user.getUserName().equals(uname)) {
				return user.getPassword();
			}
		}
		return null;
	}

}
