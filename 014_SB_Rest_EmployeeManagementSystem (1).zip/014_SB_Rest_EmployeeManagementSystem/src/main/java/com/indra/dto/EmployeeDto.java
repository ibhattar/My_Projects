package com.indra.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class EmployeeDto {

	
		private long id;
		
		@NotNull
		@Size(min =2, message ="First name should have at least 2 characters")
		@JsonProperty("fname")
		private String firstName;

		@NotNull
		@Size(min =2, message ="Last name should have at least 2 characters")
		@JsonProperty("lname")
		private String lastName;
		
		@Email
		@NotBlank
		@JsonProperty("email")
		private String email;
		
	@NotNull
	@Size(min =2,message="Passport should have at least 8 characters")
	@JsonProperty("pnumber")
		private String passportNumber;


		public long getId() {
			return id;
		}


		public void setId(long id) {
			this.id = id;
		}


		public String getFirstName() {
			return firstName;
		}


		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}


		public String getLastName() {
			return lastName;
		}


		public void setLastName(String lastName) {
			this.lastName = lastName;
		}


		public String getEmail() {
			return email;
		}


		public void setEmail(String email) {
			this.email = email;
		}


		public String getPassportNumber() {
			return passportNumber;
		}


		public void setPassportNumber(String passportNumber) {
			this.passportNumber = passportNumber;
		}


		public EmployeeDto(String firstName, String lastName, String email, String passportNumber) {
			super();
			this.firstName = firstName;
			this.lastName = lastName;
			this.email = email;
			this.passportNumber = passportNumber;
		}


		public EmployeeDto() {
			super();
			// TODO Auto-generated constructor stub
		}
		
		
	}

