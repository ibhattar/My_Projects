package com.indra.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;

@Entity
@Table(name="employees")
public class Employee {

	
	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
	
	private long id;
	
	@Column(name="fname")
	private String firstName;
	@Column(name ="lname")
	private String lastName;
	@Column(name= "email")
	private String email;
	
	@Column(name="pnumber")
	private String passportNumber;
	
	
}
