package com.indra.rest;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class MultiplyService {

	@GetMapping("/Multiply/{num1}/{num2}")
	

public int mult(@PathVariable int num1, @PathVariable int num2) {
		int mult = num1*num2;
		String Message = rs.getForObject("http://localhost:5555/Multiply/num1/num2"+mult, String.class);
		
		return mult;
	}

}
